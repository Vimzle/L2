# 🐾 Ragdoll Game

Мини-игра на Python (Pygame).

Рэгдолл собирает рыбки, чтобы поддерживать сытость.

---

## Запуск (Linux)

```bash
chmod +x run.sh
./run.sh
```
